/*
 * Copyright LWJGL. All rights reserved.
 * License terms: http://lwjgl.org/license.php
 * MACHINE GENERATED FILE, DO NOT EDIT
 */
package org.lwjgl.openal;

/** bindings to AL_EXT_EXPONENT_DISTANCE extension. */
public final class EXTExponentDistance {

	/** AL_EXT_EXPONENT_DISTANCE tokens. */
	public static final int
		AL_EXPONENT_DISTANCE         = 0xD005,
		AL_EXPONENT_DISTANCE_CLAMPED = 0xD006;

	private EXTExponentDistance() {}

}